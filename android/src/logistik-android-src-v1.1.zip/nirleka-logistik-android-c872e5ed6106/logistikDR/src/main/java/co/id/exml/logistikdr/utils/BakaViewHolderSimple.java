package co.id.exml.logistikdr.utils;

import android.widget.ImageView;
import android.widget.TextView;

public class BakaViewHolderSimple {
	public ImageView icon;
	public TextView text;
}