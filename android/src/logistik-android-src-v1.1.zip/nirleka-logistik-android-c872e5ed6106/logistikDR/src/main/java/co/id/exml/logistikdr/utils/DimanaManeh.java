package co.id.exml.logistikdr.utils;

import android.location.Location;

public interface DimanaManeh {
	
	public void found(Location location);
	
	public void hasDisable();
	
	public void timeOut();
	
	public void next();
	
}
