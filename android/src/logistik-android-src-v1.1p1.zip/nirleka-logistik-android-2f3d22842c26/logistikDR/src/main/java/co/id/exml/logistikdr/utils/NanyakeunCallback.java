package co.id.exml.logistikdr.utils;

import android.content.DialogInterface;

public interface NanyakeunCallback {
	
	public void callback( DialogInterface dialog, int which );
	
}
