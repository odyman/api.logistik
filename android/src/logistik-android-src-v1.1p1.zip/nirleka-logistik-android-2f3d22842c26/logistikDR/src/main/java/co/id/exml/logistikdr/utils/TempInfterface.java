package co.id.exml.logistikdr.utils;

public interface TempInfterface {
	
	public void onHandler();
	
}
